// Aluna: Talyta Scaramuzzo --- TIA: 32079915
//Declarando as bibliotecas que serão utilizadas
#include<stdio.h>
#include<stdlib.h>
#include<string.h>
//Criando a função main do programa
int main(void)
 {
  system("clear"); 
  //declarando Vetores (V,W,Final) e seus respectivos tamanhos;
  int VetorV [10] = {1,1,2,2,3,3,3,4,5,6};
  int VetorW [10];
  int VetorFinal [10];

  //lendo VetorV e colocando dentro do VetorW;
  int ultimo_item;
  int contador = 0;
  for(int i = 0; i <= 10; i++){
    for(int z = 0; z <= 10; z++){
      if(i == VetorV[z]){
        contador++;
      } 
    }

    VetorW[i] = contador;
    contador = 0;
  }

  // imprimindo o vetor contador;
  for(int print = 0; print <= 10; print++){
    printf("%i: %i | ", print, VetorW[print]);
    if(print % 4 == 0 ){
      printf("\n");                 
    }
  }

  //Printando vetor final
  int fim_count = 0;
  for(int print = 0; print <= 10; print++){
    for(int i = 1; i <= VetorW[print]; i++){
      VetorFinal[fim_count] = print;
      fim_count++;
    }
  }

  // imprimindo o vetor final;
  for(int print = 0; print <= 10; print++){
    printf("%i, ", VetorFinal[print]);
  }
  //retornando 0;
  return 0; 
} //fim do programa :(