#ifndef __BST_TREE_H__
#define __BST_TREE_H__

#include <iostream>
using namespace std;

class treeNode
{
public:
	int value;
	treeNode* left;
	treeNode* right;

	treeNode();

	treeNode(int v);

};


class BST
{
public:
	treeNode* root;

	BST();

	bool IsEmpty(treeNode* root);

	treeNode* treeInsert(treeNode* root, treeNode* no);

	void treePrint(treeNode* root);

	treeNode* treeSearch(treeNode* root, int val);

	treeNode* treeRemove(treeNode* root, int val);

	treeNode* minValue(treeNode* node);

	int treeHeight(treeNode* root);
};


#endif
