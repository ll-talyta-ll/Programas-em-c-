// NOME: LEONARDO SANTOS DA ROCHA   | T.I.A.: 32092261
// NOME: VITOR UEMA SOUSA           | T.I.A.: 32028555
// TURMA: CC04D

// IMPLEMENTA��O DA �RVORE BIN�RIA DE BUSCA

#include <iostream>
#include "BST.h"
int main()
{
    setlocale(LC_ALL, "pt_BR");
    int opcao, val;
    BST arvore;
    do
    {
        cout << "\nQual opera��o deseja fazer?";
        cout << "\n1 - Inserir n�";
        cout << "\n2 - Procurar valor";
        cout << "\n3 - Remover n�";
        cout << "\n4 - Imprimir �rvore";
        cout << "\n5 - Altura da �rvore";
        cout << "\n0 - Sair do programa\n";

        cin >> opcao;

        treeNode* no = new treeNode();

        switch (opcao)
        {
        case 0:
            break;
        case 1:
            //c�digo insert
            cout << "Insira o valor desejado: ";
            cin >> val;
            no->value = val;
            arvore.root = arvore.treeInsert(arvore.root, no);
            break;
        case 2:
            //c�digo search
            cout << "Insira o valor a ser pesquisado: ";
            cin >> val;
            arvore.treeSearch(arvore.root, val);
            break;
        case 3:
            cout << "Insira o valor a ser deletado: ";
            cin >> val;
            arvore.treeRemove(arvore.root, val);
            break;
        case 4:
            arvore.treePrint(arvore.root);
            cout << "\n";
            break;
        case 5:
            int height = arvore.treeHeight(arvore.root);
            cout << "Altura = " << height << "\n";
            break;
        }

    } while (opcao != 0);
}