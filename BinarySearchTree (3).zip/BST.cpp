#include "BST.h"

treeNode::treeNode()
	:value(0)
	, left(NULL)
	, right(NULL)
{
}

treeNode::treeNode(int v)
	:value(v)
	, left(NULL)
	, right(NULL)
{
}

BST::BST()
{
	root = NULL;
}

bool BST::IsEmpty(treeNode* root)
{
	if (root == NULL)
	{
		return true;
	}
	else
	{
		return false;
	}
}

treeNode* BST::treeInsert(treeNode* root, treeNode* no)
{
	if (IsEmpty(root) == true)
	{
		root = no;
		cout << "Inser��o bem sucedida!\n";
		return root;
	}

	if (no->value < root->value)
	{
		root->left = treeInsert(root->left, no);
	}
	else if (no->value > root->value)
	{
		root->right = treeInsert(root->right, no);
	}
	else
	{
		cout << "Valor inserido j� existe!\n";
		return root;
	}
	return root;
}

void BST::treePrint(treeNode* root)
{
	if (root == NULL)
	{
		return;
	}

	treePrint(root->left);
	cout << root->value << " ";
	treePrint(root->right);

	return;
}

treeNode* BST::treeSearch(treeNode* root, int val)
{
	if (root == NULL)
	{
		cout << "Valor n�o encontrado!\n";
		return NULL;
	}

	if (root->value == val)
	{
		cout << "Valor encontrado!\n";
		return root;
	}
	else if (val > root->value)
	{
		root = treeSearch(root->right, val);
	}
	else if (val < root->value)
	{
		root = treeSearch(root->left, val);
	}

	return root;
}

treeNode* BST::treeRemove(treeNode* root, int val)
{
	if (root == NULL)
	{
		return NULL;
	}

	else if (val < root->value)
	{
		root->left = treeRemove(root->left, val);
	}
	else if (val > root->value)
	{
		root->right = treeRemove(root->right, val);
	}

	else
	{
		if (root->left == NULL)
		{
			treeNode* temp = root->right;
			delete root;
			return temp;
		}
		else if (root->right == NULL)
		{
			treeNode* temp = root->left;
			delete root;
			return temp;
		}
		else
		{
			treeNode* temp = minValue(root->right);
			root->value = temp->value;
			root->right = treeRemove(root->right, temp->value);
		}
	}
	return root;
}

treeNode* BST::minValue(treeNode* node)
{
	treeNode* current = node;
	while (current->left != NULL)
	{
		current = current->left;
	}
	return current;
}

int BST::treeHeight(treeNode* root)
{
	if (root == NULL)
	{
		return -1;
	}
	int left_height = treeHeight(root->left);
	int right_height = treeHeight(root->right);

	if (left_height > right_height)
	{
		return left_height + 1;
	}
	else
	{
		return right_height + 1;
	}
}