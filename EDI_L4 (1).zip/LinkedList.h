#ifndef __LINKED_LIST_H__
#define __LINKED_LIST_H__

struct Node
{
	int data;
	Node* next;
};

struct LinkedList
{
	int count;
	Node* head;
	Node* tail;
};

LinkedList* Create();
void Destroy(LinkedList* list);
void Insert(LinkedList* list, int value);
void Append(LinkedList* list, int value);
Node* RemoveHead(LinkedList* list);
Node* RemoveTail(LinkedList* list);
Node* RemoveNode(LinkedList* list, int value); 
Node* GetHead(const LinkedList* list);
Node* GetTail(const LinkedList* list);
Node* GetNode(const LinkedList* list, int value);
int Count(const LinkedList* list);
bool IsEmpty(const LinkedList* list);
void Clear(LinkedList* list);

Node* CreateNode(int data, Node* next);
void DestroyNode(Node* node);

#endif //  __LINKED_LIST_H__