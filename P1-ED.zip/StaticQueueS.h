#pragma once
#ifndef __STATIC_QUEUES_H__
#define __STATIC_QUEUES_H__

const int STATIC_QUEUES_CAPACITY = 8;

struct StaticQueueS
{
	int current;
	char values[STATIC_QUEUES_CAPACITY];
};

StaticQueueS Create();

bool Enqueue(StaticQueueS& queue, char valor);

bool IsEmpty(const StaticQueueS& queue);

char Dequeue(StaticQueueS& queue);

char Front(StaticQueueS& queue);

int Count(const StaticQueueS& queue);

int Size(const StaticQueueS& queue);

bool Clear(StaticQueueS& queue);

#endif