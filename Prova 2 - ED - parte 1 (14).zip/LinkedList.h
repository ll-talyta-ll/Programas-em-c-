//Aluna: Talyta Scaramuzzo --- TIA: 32079915;
//Solucao P2 - ESTRUTURA DE DADOS 1(parte 1);
//Refer�ncias: solu��o lista de exerc�cios 4 - struct;
//Refer�ncias: Material LinkedList - semana 13;
//Refer�ncias: MIZRAHI, V. V. Treinamento em Linguagem C++: m�dulo 2 - 2� edi��o. S�o Paulo: Editora Pearson, 2006. 
//Cap�tulo 8 - Classes e objetos.
//Refer�ncias: CELES, W.; CERQUEIRA, R.; RANGEL, J. L. Introdu��o a Estrutura de Dados com t�cnicas em programa��o em C, 2� edi��o. Rio de Janeiro: Elsevier, 2016.
//Cap�tulo 14 - Listas encadeadas, se��o 14.2.1 (Listas circulares) e se��o 14.3 (Listas duplamente encadeadas).
//Refer�ncias: EDI_P2.pdf;
#pragma once
#ifndef __LINKED_LIST_H__
#define __LINKED_LIST_H__
#include <string>
using namespace std;

struct Node
{
	int indentidade;
	string word;
	Node* next;
};

struct LinkedList
{
	int count;
	Node* head;
	Node* tail;
};

LinkedList* Create();
void Destroy(LinkedList* list);
void Insert(LinkedList* list, int value, string word);
//precisa ser bool porque tem que ser poss�vel retornar false;
//Adicionei a fun��o InsertBefore;
bool InsertBefore(LinkedList* list, int beforeId, int indentidade, string word);
//Adicionei a fun��o InsertAfter;
//precisa ser bool porque tem que ser poss�vel retornar false;
bool InsertAfter(LinkedList* list, int afterId, int indentidade, string word);
void Append(LinkedList* list, int value, string word);
Node* RemoveHead(LinkedList* list);
Node* RemoveTail(LinkedList* list);
Node* RemoveNode(LinkedList* list, int value);
Node* GetHead(const LinkedList* list);
Node* GetTail(const LinkedList* list);
Node* GetNode(const LinkedList* list, int value);
int Count(const LinkedList* list);
bool IsEmpty(const LinkedList* list);
void Clear(LinkedList* list);

Node* CreateNode(int data, Node* next, string word);
void DestroyNode(Node* node);

#endif //  __LINKED_LIST_H__