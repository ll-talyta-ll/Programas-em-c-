//Aluna: Talyta Scaramuzzo --- TIA: 32079915;
//Solucao P2 - ESTRUTURA DE DADOS 1(parte 1);
//Refer�ncias: solu��o lista de exerc�cios 4 - struct;
//Refer�ncias: Material LinkedList - semana 13;
//Refer�ncias: MIZRAHI, V. V. Treinamento em Linguagem C++: m�dulo 2 - 2� edi��o. S�o Paulo: Editora Pearson, 2006. 
//Cap�tulo 8 - Classes e objetos.
//Refer�ncias: CELES, W.; CERQUEIRA, R.; RANGEL, J. L. Introdu��o a Estrutura de Dados com t�cnicas em programa��o em C, 2� edi��o. Rio de Janeiro: Elsevier, 2016.
//Cap�tulo 14 - Listas encadeadas, se��o 14.2.1 (Listas circulares) e se��o 14.3 (Listas duplamente encadeadas).
//Refer�ncias: EDI_P2.pdf;
#include "LinkedList.h"

LinkedList* Create() //Criando a Linkedlist;
{
	LinkedList* list = new LinkedList;
	list->count = 0;
	list->head = nullptr;
	list->tail = nullptr;

	return list;
}

void Destroy(LinkedList* list) 
{
	Clear(list);

	delete list;
	list = nullptr;
}

void Insert(LinkedList* list, int value, string word)
{
	Node* node = CreateNode(value, list->head, word);

	if (IsEmpty(list))
	{
		list->tail = node;
	}

	list->head = node;
	++list->count;
}
//fun��o InsertBefore com seus par�metros;
bool InsertBefore(LinkedList* list,int beforeId, int indentidade, string word) 
{
	Node* node = list->head;
	Node* anterior = nullptr;

	if (IsEmpty(list)) // se a lista estiver vazia;
	{
		return false; //retornar� false;
	}

	while (node != nullptr && node->indentidade != beforeId) //loop para que node seja diferente de nulo;
	{
		anterior = node;
		node = node->next;
	}

	if (node == list->head)
	{
		Node* nodebefore = new Node;
		nodebefore->indentidade = indentidade;
		nodebefore->word = word;
		nodebefore->next = list->head;
		list->head = nodebefore;
		++list->count;
		return true;
	}
	else if (node != nullptr)
	{
		Node* nodebefore = new Node;
		nodebefore->indentidade = indentidade;
		nodebefore->word = word;
		nodebefore->next = anterior->next;
		anterior->next = nodebefore;
		++list->count;
		return true;
	}
	else
	{
		return false;
	}
}
//fun��o InsertAfter com seus par�metros;
bool InsertAfter(LinkedList* list, int afterId, int indentidade, string word)
{
	Node* node = list->head;

	if (IsEmpty(list)) // se a lista estiver vazia;
	{
		return false;  //retornar� false;
	}

	while (node != nullptr && node->indentidade != afterId) //loop para que node seja diferente de nulo;
	{
		node = node->next;
	}
	if (node == list->tail)
	{
		Node* nodeafter = new Node;
		nodeafter->indentidade = indentidade;
		nodeafter->word = word;
		nodeafter->next = nullptr;
		list->tail->next = nodeafter;
		list->tail = nodeafter;
		++list->count;
		return true;
	}
	else if (node != nullptr)
	{
		Node* nodeafter = new Node;
		nodeafter->indentidade = indentidade;
		nodeafter->word = word;
		nodeafter->next = node->next;
		node->next = nodeafter;
		++list->count;
		return true;
	}
	else
	{
		return false;
	}

}

void Append(LinkedList* list, int value, string word)
{
	Node* node = CreateNode(value, nullptr, word);

	if (IsEmpty(list))
	{
		list->head = list->tail = node;
	}
	else
	{
		list->tail->next = node;
		list->tail = node;
	}

	++list->count;
}

Node* RemoveHead(LinkedList* list)
{
	if (IsEmpty(list))
	{
		return nullptr;
	}

	Node* toRemove = list->head;

	if (list->head == list->tail)
	{
		list->head = list->tail = nullptr;
	}
	else
	{
		list->head = list->head->next;
	}

	--list->count;

	toRemove->next = nullptr;
	return toRemove;
}

Node* RemoveTail(LinkedList* list)
{
	if (list->head == list->tail)
	{
		return RemoveHead(list);
	}

	Node* toRemove = list->head;
	Node* previous = nullptr;

	while (toRemove != list->tail)
	{
		previous = toRemove;
		toRemove = toRemove->next;
	}

	previous->next = nullptr;
	list->tail = previous;

	--list->count;

	toRemove->next = nullptr;
	return toRemove;
}

Node* RemoveNode(LinkedList* list, int value)
{
	Node* toRemove = list->head;
	Node* previous = nullptr;

	while (toRemove != nullptr && toRemove->indentidade != value)
	{
		previous = toRemove;
		toRemove = toRemove->next;
	}

	if (toRemove == list->head)
	{
		return RemoveHead(list);
	}
	else if (toRemove == list->tail)
	{
		return RemoveTail(list);
	}
	else if (toRemove != nullptr)
	{
		previous->next = toRemove->next;

		--list->count;

		toRemove->next = nullptr;
		return toRemove;
	}

	return nullptr;
}

Node* GetHead(const LinkedList* list)
{
	return list->head;
}

Node* GetTail(const LinkedList* list)
{
	return list->tail;
}

Node* GetNode(const LinkedList* list, int value)
{
	Node* node = list->head;
	while (node != nullptr)
	{
		if (node->indentidade == value)
		{
			return node;
		}
		node = node->next;
	}

	return nullptr;
}

int Count(const LinkedList* list)
{
	return list->count;
}

bool IsEmpty(const LinkedList* list)
{
	return list->head == nullptr && list->tail == nullptr;
}

void Clear(LinkedList* list)
{
	Node* node = list->head;
	Node* next = nullptr;

	while (node != nullptr)
	{
		next = node->next;
		DestroyNode(node);
		node = next;
	}

	list->head = list->tail = nullptr;
	list->count = 0;
}

Node* CreateNode(int indentidade, Node* next, string word)
{
	Node* node = new Node;
	node->indentidade = indentidade;
	node->word = word;
	node->next = next;

	return node;
}

void DestroyNode(Node* node)
{
	delete node;
	node = nullptr;
}
