/*
Gustavo Hiroshi Yoshio
32033273
03-D
*/

#include<stdio.h>
#include<stdlib.h>
#include<string.h>

int main(void) {
  system("clear");
  
  int Vetor_Main [50] = {2,3,1,4,5,6,7,8,1,2,3,4,5,2,1,6,7,8,9,2,1,2,3,4,5,6,7,8,5,4,3,1,2,3,7,8,9,9,0,3,5,7,3,2,5,6,7,8,9,3};
  int Vetor_aux [50];
  int Vetor_Final [50];

  //lendo Vetor main e colocando dentro do aux
  int last_item;
  int contador = 0;
  for(int i = 0; i <= 50; i++){
    for(int mc = 0; mc <= 50; mc++){
      if(i == Vetor_Main[mc]){
        contador++;
      } 
    }

    Vetor_aux[i] = contador;
    contador = 0;
  }

  // imprimindo o array que conta
  for(int print = 0; print <= 50; print++){
    printf("%i: %i | ", print, Vetor_aux[print]);
    if(print % 4 == 0 ){
      printf("\n");                 
    }
  }
  printf("\n\n\n");

  // montando o vetor final
  int final_count = 0;
  for(int print = 0; print <= 50; print++){
    for(int i = 1; i <= Vetor_aux[print]; i++){
      //printf("%i, ", print);
      Vetor_Final[final_count] = print;
      final_count++;
    }
  }
  //printf("\n\n\n");

  // imprimindo o vetor final
  for(int print = 0; print <= 50; print++){
    printf("%i, ", Vetor_Final[print]);
  }

  
  return 0;
}